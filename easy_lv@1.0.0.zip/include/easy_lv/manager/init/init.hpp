#include "../task_handler/task_handler.hpp"
#include "liblvgl/lvgl.h"

void init();
